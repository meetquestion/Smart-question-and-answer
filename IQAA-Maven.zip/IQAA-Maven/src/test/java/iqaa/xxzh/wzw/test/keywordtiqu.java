package iqaa.xxzh.wzw.test;

import java.util.Collection;
import java.util.List;

import org.ansj.app.keyword.KeyWordComputer;
import org.ansj.app.keyword.Keyword;
import org.junit.Test;

public class keywordtiqu {
	
	/**
	 * 没有content，直接对一句话打分
	 * 这个方法
	 * 1.个人感觉可以将这句话的后面的东西接在一起，使其准确度更高感觉如果后面的打分是前一个的一半以下，就没有必要去取他
	 * 2.这个接在一起不一定是连续的，所以可以在sql查询的时候设置同时包含这些打分高的词
	 * 3.这里面好像没有英文的打分，可以尝试先将英文算作关键词（按照华为云的网页可能性）
	 * 4.再考虑英文+关键词打分最高的一到两个关键词形成组合
	 * 这个不具有普适性，因为用户问题感觉上不会特别长
	 * 5.哇，又想到一点，当问题特别长的的时候（说明用户啰嗦，或者对这个不是特别懂），这时候上面的就不是特别适用，所以只去前三个
	 */
	@Test
	public void run1(){
		//String str="维基解密否认斯诺登接受委内瑞拉庇护";
		//String str="无法访问机器学习服务实例时怎么处理？";
		//String str="机器学习服务支持哪些格式的数据源？";
		//String str="是否支持实例扩容？";
		//String str="UQuery适用哪些场景";
		String str="有俄罗斯国会议员，9号在社交网站推特表示，美国中情局前雇员斯诺登，已经接受委内瑞拉的庇护，不过推文在发布几分钟后随即删除。俄罗斯当局拒绝发表评论，而一直协助斯诺登的维基解密否认他将投靠委内瑞拉。　　俄罗斯国会国际事务委员会主席普什科夫，在个人推特率先披露斯诺登已接受委内瑞拉的庇护建议，令外界以为斯诺登的动向终于有新进展。　　不过推文在几分钟内旋即被删除，普什科夫澄清他是看到俄罗斯国营电视台的新闻才这样说，而电视台已经作出否认，称普什科夫是误解了新闻内容。　　委内瑞拉驻莫斯科大使馆、俄罗斯总统府发言人、以及外交部都拒绝发表评论。而维基解密就否认斯诺登已正式接受委内瑞拉的庇护，说会在适当时间公布有关决定。　　斯诺登相信目前还在莫斯科谢列梅捷沃机场，已滞留两个多星期。他早前向约20个国家提交庇护申请，委内瑞拉、尼加拉瓜和玻利维亚，先后表示答应，不过斯诺登还没作出决定。　　而另一场外交风波，玻利维亚总统莫拉莱斯的专机上星期被欧洲多国以怀疑斯诺登在机上为由拒绝过境事件，涉事国家之一的西班牙突然转口风，外长马加略]号表示愿意就任何误解致歉，但强调当时当局没有关闭领空或不许专机降落。";
		
		KeyWordComputer kwc = new KeyWordComputer(10);
		//Collection<Keyword> result = kwc.computeArticleTfidf(str);
		//System.out.println(result);
		List<Keyword> list = kwc.computeArticleTfidf(str);
		for (Keyword keyword : list) {
			System.out.println(keyword.getName()+"  "+keyword.getScore()+"  "+keyword.getFreq());
		}
		
	}
	
	
	public static void main(String[] args) {
		KeyWordComputer kwc = new KeyWordComputer(5); 
		String title = "维基解密否认斯诺登接受委内瑞拉庇护"; String content = "有俄罗斯国会议员，9号在社交网站推特表示，美国中情局前雇员斯诺登，已经接受委内瑞拉的庇护，不过推文在发布几分钟后随即删除。俄罗斯当局拒绝发表评论，而一直协助斯诺登的维基解密否认他将投靠委内瑞拉。　　俄罗斯国会国际事务委员会主席普什科夫，在个人推特率先披露斯诺登已接受委内瑞拉的庇护建议，令外界以为斯诺登的动向终于有新进展。　　不过推文在几分钟内旋即被删除，普什科夫澄清他是看到俄罗斯国营电视台的新闻才这样说，而电视台已经作出否认，称普什科夫是误解了新闻内容。　　委内瑞拉驻莫斯科大使馆、俄罗斯总统府发言人、以及外交部都拒绝发表评论。而维基解密就否认斯诺登已正式接受委内瑞拉的庇护，说会在适当时间公布有关决定。　　斯诺登相信目前还在莫斯科谢列梅捷沃机场，已滞留两个多星期。他早前向约20个国家提交庇护申请，委内瑞拉、尼加拉瓜和玻利维亚，先后表示答应，不过斯诺登还没作出决定。　　而另一场外交风波，玻利维亚总统莫拉莱斯的专机上星期被欧洲多国以怀疑斯诺登在机上为由拒绝过境事件，涉事国家之一的西班牙突然转口风，外长马加略]号表示愿意就任何误解致歉，但强调当时当局没有关闭领空或不许专机降落。"; 
		Collection<Keyword> result = kwc.computeArticleTfidf(title, content); 
		System.out.println(result);
	}
}
