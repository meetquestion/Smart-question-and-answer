package iqaa.xxzh.wzw.domain;

public class Aanswer {
	private Integer code;
	private String text;
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	
}
