package iqaa.xxzh.wzw.service;

import iqaa.xxzh.msl.bean.Answer;

public interface QAService {

	Answer getByQuestion(String question);

}
