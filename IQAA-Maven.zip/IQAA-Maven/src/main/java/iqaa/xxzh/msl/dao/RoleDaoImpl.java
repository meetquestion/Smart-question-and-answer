package iqaa.xxzh.msl.dao;

import org.springframework.stereotype.Component;

import iqaa.xxzh.common.bean.Role;

@Component(value="roleDao")
public class RoleDaoImpl extends BaseDao<Role> implements RoleDao {


}
