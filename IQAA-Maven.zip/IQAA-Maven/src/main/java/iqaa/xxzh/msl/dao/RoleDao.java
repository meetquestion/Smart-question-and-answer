package iqaa.xxzh.msl.dao;

import iqaa.xxzh.common.bean.Role;

public interface RoleDao extends Dao<Role> {

}
