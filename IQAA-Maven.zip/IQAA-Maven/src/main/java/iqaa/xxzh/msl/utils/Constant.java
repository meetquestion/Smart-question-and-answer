package iqaa.xxzh.msl.utils;

public class Constant {

	public final static String SESSION_USER = "session_user_bean";
	public static final String MSG = "msg";
	public static final String QUESTIONS = "questions";
	public static String DOC_PAGINATION = "docPageInfo";
	public static String PAGEBEAN = "pageBean";
}
